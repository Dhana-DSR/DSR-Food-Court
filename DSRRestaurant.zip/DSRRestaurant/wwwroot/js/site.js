// Progressive enhancement only — every form here also works with JS disabled.

document.addEventListener("DOMContentLoaded", () => {
    // Quantity steppers: any element with [data-step] adjusts the sibling number input.
    document.querySelectorAll("[data-step]").forEach((btn) => {
        btn.addEventListener("click", () => {
            const input = btn.parentElement.querySelector('input[type="number"]');
            if (!input) return;
            const delta = parseInt(btn.getAttribute("data-step"), 10);
            const min = parseInt(input.min || "0", 10);
            const next = Math.max(min, (parseInt(input.value, 10) || 0) + delta);
            input.value = next;
        });
    });

    // Auto-dismiss flash messages after a few seconds.
    document.querySelectorAll(".flash").forEach((el) => {
        setTimeout(() => el.style.display = "none", 5000);
    });
});
