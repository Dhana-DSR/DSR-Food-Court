using System.Text.Json;
using DSRRestaurant.Models;
using Microsoft.AspNetCore.Http;

namespace DSRRestaurant.Services;

/// <summary>
/// Stores the shopping cart as JSON in the visitor's session — no database needed.
/// The cart is scoped per browser session and cleared once the order is placed.
/// </summary>
public static class CartSessionExtensions
{
    private const string CartKey = "DSR_CART";

    public static List<CartItem> GetCart(this ISession session)
    {
        var json = session.GetString(CartKey);
        if (string.IsNullOrEmpty(json)) return new List<CartItem>();
        return JsonSerializer.Deserialize<List<CartItem>>(json) ?? new List<CartItem>();
    }

    public static void SaveCart(this ISession session, List<CartItem> cart)
    {
        session.SetString(CartKey, JsonSerializer.Serialize(cart));
    }

    public static void AddToCart(this ISession session, MenuItem item, int quantity)
    {
        var cart = session.GetCart();
        var existing = cart.FirstOrDefault(c => c.MenuItemId == item.Id);
        if (existing is not null)
        {
            existing.Quantity += quantity;
        }
        else
        {
            cart.Add(new CartItem
            {
                MenuItemId = item.Id,
                Name = item.Name,
                Price = item.Price,
                Quantity = quantity,
                TicketCode = item.TicketCode
            });
        }
        session.SaveCart(cart);
    }

    public static void UpdateQuantity(this ISession session, int menuItemId, int quantity)
    {
        var cart = session.GetCart();
        var existing = cart.FirstOrDefault(c => c.MenuItemId == menuItemId);
        if (existing is null) return;

        if (quantity <= 0)
            cart.Remove(existing);
        else
            existing.Quantity = quantity;

        session.SaveCart(cart);
    }

    public static void RemoveFromCart(this ISession session, int menuItemId)
    {
        var cart = session.GetCart();
        cart.RemoveAll(c => c.MenuItemId == menuItemId);
        session.SaveCart(cart);
    }

    public static void ClearCart(this ISession session)
    {
        session.Remove(CartKey);
    }
}
