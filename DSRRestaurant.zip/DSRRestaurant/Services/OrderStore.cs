using DSRRestaurant.Models;

namespace DSRRestaurant.Services;

public class OrderStore
{
    private readonly object _lock = new();
    private readonly List<Order> _orders = new();
    private int _nextId = 1001; // start ticket numbers at a nice round-looking number

    public Order Add(Order order)
    {
        lock (_lock)
        {
            order.Id = _nextId++;
            _orders.Add(order);
            return order;
        }
    }

    public List<Order> GetAll()
    {
        lock (_lock) return _orders.OrderByDescending(o => o.PlacedAtUtc).ToList();
    }

    public Order? GetById(int id)
    {
        lock (_lock) return _orders.FirstOrDefault(o => o.Id == id);
    }

    public bool UpdateStatus(int id, OrderStatus status)
    {
        lock (_lock)
        {
            var order = _orders.FirstOrDefault(o => o.Id == id);
            if (order is null) return false;
            order.Status = status;
            return true;
        }
    }
}
