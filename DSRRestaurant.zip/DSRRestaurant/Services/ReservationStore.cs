using DSRRestaurant.Models;

namespace DSRRestaurant.Services;

public class ReservationStore
{
    private readonly object _lock = new();
    private readonly List<Reservation> _reservations = new();
    private int _nextId = 1;

    public Reservation Add(Reservation reservation)
    {
        lock (_lock)
        {
            reservation.Id = _nextId++;
            _reservations.Add(reservation);
            return reservation;
        }
    }

    public List<Reservation> GetAll()
    {
        lock (_lock) return _reservations.OrderBy(r => r.Date).ThenBy(r => r.Time).ToList();
    }

    public Reservation? GetById(int id)
    {
        lock (_lock) return _reservations.FirstOrDefault(r => r.Id == id);
    }

    public bool UpdateStatus(int id, ReservationStatus status)
    {
        lock (_lock)
        {
            var reservation = _reservations.FirstOrDefault(r => r.Id == id);
            if (reservation is null) return false;
            reservation.Status = status;
            return true;
        }
    }
}
