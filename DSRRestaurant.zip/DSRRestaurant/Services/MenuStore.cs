using DSRRestaurant.Models;

namespace DSRRestaurant.Services;

/// <summary>
/// Hardcoded, in-memory menu "database". Thread-safe for a small single-instance app.
/// Data resets whenever the app restarts — plug in EF Core here if you add real storage.
/// </summary>
public class MenuStore
{
    private readonly object _lock = new();
    private readonly List<MenuItem> _items;
    private int _nextId;

    public MenuStore()
    {
        _items = new List<MenuItem>
        {
            new() { Id = 1, Name = "Charred Corn & Chili Fritters", Description = "Sweetcorn fritters, lime crema, pickled chili.", Price = 8.50m, Category = MenuCategory.Starters, IsVegetarian = true, IsSpicy = true },
            new() { Id = 2, Name = "Smoked Paprika Calamari", Description = "Flash-fried squid, smoked paprika aioli, lemon.", Price = 10.00m, Category = MenuCategory.Starters },
            new() { Id = 3, Name = "Roasted Beet & Whipped Feta", Description = "Heirloom beets, whipped feta, hazelnut dukkah.", Price = 9.00m, Category = MenuCategory.Starters, IsVegetarian = true },

            new() { Id = 4, Name = "DSR Signature Butter Chicken", Description = "Slow-simmered tomato-butter gravy, tandoori chicken, basmati.", Price = 17.50m, Category = MenuCategory.Mains, IsSpicy = true },
            new() { Id = 5, Name = "Wild Mushroom Risotto", Description = "Arborio rice, forest mushrooms, aged parmesan, truffle oil.", Price = 16.00m, Category = MenuCategory.Mains, IsVegetarian = true },
            new() { Id = 6, Name = "Charcoal Grilled Salmon", Description = "Citrus-glazed salmon, charred greens, herb oil.", Price = 19.00m, Category = MenuCategory.Mains },
            new() { Id = 7, Name = "Smoky Black Bean Chili Bowl", Description = "Slow-cooked black beans, roast corn, avocado, lime crema.", Price = 14.50m, Category = MenuCategory.Mains, IsVegetarian = true, IsSpicy = true },

            new() { Id = 8, Name = "The DSR Tomahawk", Description = "28-day aged tomahawk, chimichurri, smoked salt.", Price = 42.00m, Category = MenuCategory.Grill },
            new() { Id = 9, Name = "Peri-Peri Half Chicken", Description = "Flame-grilled, house peri-peri glaze, slaw.", Price = 18.50m, Category = MenuCategory.Grill, IsSpicy = true },
            new() { Id = 10, Name = "Grilled Halloumi Skewers", Description = "Charred halloumi, bell pepper, zaatar oil.", Price = 13.00m, Category = MenuCategory.Grill, IsVegetarian = true },

            new() { Id = 11, Name = "Burnt Basque Cheesecake", Description = "Caramelized top, silky center, berry compote.", Price = 8.00m, Category = MenuCategory.Desserts, IsVegetarian = true },
            new() { Id = 12, Name = "Dark Chocolate Fondant", Description = "Molten center, salted caramel ice cream.", Price = 9.00m, Category = MenuCategory.Desserts, IsVegetarian = true },

            new() { Id = 13, Name = "Smoked Old Fashioned (Mocktail)", Description = "Applewood-smoked, bitters, orange peel.", Price = 7.00m, Category = MenuCategory.Drinks, IsVegetarian = true },
            new() { Id = 14, Name = "House Ginger-Mint Cooler", Description = "Fresh ginger, mint, lime, soda.", Price = 5.50m, Category = MenuCategory.Drinks, IsVegetarian = true },
        };
        _nextId = _items.Max(i => i.Id) + 1;
    }

    public List<MenuItem> GetAll()
    {
        lock (_lock) return _items.OrderBy(i => i.Category).ThenBy(i => i.Name).ToList();
    }

    public List<MenuItem> GetAvailable()
    {
        lock (_lock) return _items.Where(i => i.IsAvailable).OrderBy(i => i.Category).ThenBy(i => i.Name).ToList();
    }

    public MenuItem? GetById(int id)
    {
        lock (_lock) return _items.FirstOrDefault(i => i.Id == id);
    }

    public MenuItem Add(MenuItem item)
    {
        lock (_lock)
        {
            item.Id = _nextId++;
            _items.Add(item);
            return item;
        }
    }

    public bool Update(MenuItem updated)
    {
        lock (_lock)
        {
            var existing = _items.FirstOrDefault(i => i.Id == updated.Id);
            if (existing is null) return false;

            existing.Name = updated.Name;
            existing.Description = updated.Description;
            existing.Price = updated.Price;
            existing.Category = updated.Category;
            existing.IsVegetarian = updated.IsVegetarian;
            existing.IsSpicy = updated.IsSpicy;
            existing.IsAvailable = updated.IsAvailable;
            return true;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock) return _items.RemoveAll(i => i.Id == id) > 0;
    }
}
