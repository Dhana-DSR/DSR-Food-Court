using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

public class AccountController : Controller
{
    // Demo credentials only — change these, or better, wire up ASP.NET Core Identity
    // with a real user store before deploying this anywhere public.
    private const string AdminUsername = "admin";
    private const string AdminPassword = "DSR@dmin123";

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Login(string username, string password, string? returnUrl = null)
    {
        if (username == AdminUsername && password == AdminPassword)
        {
            HttpContext.Session.SetString("IsAdmin", "true");
            HttpContext.Session.SetString("AdminName", username);
            return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? Redirect(returnUrl)
                : RedirectToAction("Index", "Admin");
        }

        ViewBag.ReturnUrl = returnUrl;
        ViewBag.Error = "Invalid username or password.";
        return View();
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Remove("IsAdmin");
        HttpContext.Session.Remove("AdminName");
        return RedirectToAction("Index", "Home");
    }
}
