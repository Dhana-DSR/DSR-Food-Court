using DSRRestaurant.Models;
using DSRRestaurant.Services;
using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

public class MenuController : Controller
{
    private readonly MenuStore _menuStore;

    public MenuController(MenuStore menuStore)
    {
        _menuStore = menuStore;
    }

    public IActionResult Index(MenuCategory? category)
    {
        var items = _menuStore.GetAvailable();
        if (category.HasValue)
            items = items.Where(i => i.Category == category.Value).ToList();

        ViewBag.SelectedCategory = category;
        return View(items);
    }
}
