using DSRRestaurant.Models;
using DSRRestaurant.Services;
using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

public class CartController : Controller
{
    private readonly MenuStore _menuStore;
    private readonly OrderStore _orderStore;

    public CartController(MenuStore menuStore, OrderStore orderStore)
    {
        _menuStore = menuStore;
        _orderStore = orderStore;
    }

    public IActionResult Index()
    {
        return View(HttpContext.Session.GetCart());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Add(int id, int quantity = 1)
    {
        var item = _menuStore.GetById(id);
        if (item is null || !item.IsAvailable)
        {
            TempData["Error"] = "That item isn't available right now.";
            return RedirectToAction("Index", "Menu");
        }

        HttpContext.Session.AddToCart(item, Math.Max(1, quantity));
        TempData["Success"] = $"Added {item.Name} to your order.";
        return RedirectToAction("Index", "Menu");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult UpdateQuantity(int id, int quantity)
    {
        HttpContext.Session.UpdateQuantity(id, quantity);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Remove(int id)
    {
        HttpContext.Session.RemoveFromCart(id);
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Checkout()
    {
        var cart = HttpContext.Session.GetCart();
        if (cart.Count == 0) return RedirectToAction(nameof(Index));
        return View(new Order { Items = cart });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult PlaceOrder(Order order)
    {
        var cart = HttpContext.Session.GetCart();
        if (cart.Count == 0)
        {
            TempData["Error"] = "Your cart is empty.";
            return RedirectToAction("Index", "Menu");
        }

        if (order.FulfillmentType == FulfillmentType.Delivery && string.IsNullOrWhiteSpace(order.Address))
            ModelState.AddModelError(nameof(order.Address), "Address is required for delivery.");

        if (string.IsNullOrWhiteSpace(order.CustomerName) || string.IsNullOrWhiteSpace(order.Phone))
            ModelState.AddModelError(string.Empty, "Name and phone are required.");

        if (!ModelState.IsValid)
        {
            order.Items = cart;
            return View("Checkout", order);
        }

        order.Items = cart;
        var placed = _orderStore.Add(order);
        HttpContext.Session.ClearCart();

        return RedirectToAction(nameof(Confirmation), new { id = placed.Id });
    }

    public IActionResult Confirmation(int id)
    {
        var order = _orderStore.GetById(id);
        if (order is null) return RedirectToAction("Index", "Home");
        return View(order);
    }
}
