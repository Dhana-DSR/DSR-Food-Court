using DSRRestaurant.Filters;
using DSRRestaurant.Models;
using DSRRestaurant.Services;
using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

[RequireAdmin]
public class AdminController : Controller
{
    private readonly MenuStore _menuStore;
    private readonly OrderStore _orderStore;
    private readonly ReservationStore _reservationStore;

    public AdminController(MenuStore menuStore, OrderStore orderStore, ReservationStore reservationStore)
    {
        _menuStore = menuStore;
        _orderStore = orderStore;
        _reservationStore = reservationStore;
    }

    public IActionResult Index()
    {
        ViewBag.OrderCount = _orderStore.GetAll().Count(o => o.Status is OrderStatus.Placed or OrderStatus.InKitchen);
        ViewBag.ReservationCount = _reservationStore.GetAll().Count(r => r.Status == ReservationStatus.Pending);
        ViewBag.MenuCount = _menuStore.GetAll().Count;
        return View();
    }

    // ---------- Orders ----------

    public IActionResult Orders() => View(_orderStore.GetAll());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult UpdateOrderStatus(int id, OrderStatus status)
    {
        _orderStore.UpdateStatus(id, status);
        return RedirectToAction(nameof(Orders));
    }

    // ---------- Reservations ----------

    public IActionResult Reservations() => View(_reservationStore.GetAll());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult UpdateReservationStatus(int id, ReservationStatus status)
    {
        _reservationStore.UpdateStatus(id, status);
        return RedirectToAction(nameof(Reservations));
    }

    // ---------- Menu ----------

    public IActionResult Menu() => View(_menuStore.GetAll());

    public IActionResult CreateMenuItem() => View("EditMenuItem", new MenuItem());

    public IActionResult EditMenuItem(int id)
    {
        var item = _menuStore.GetById(id);
        if (item is null) return RedirectToAction(nameof(Menu));
        return View(item);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult SaveMenuItem(MenuItem item)
    {
        if (!ModelState.IsValid) return View("EditMenuItem", item);

        if (item.Id == 0)
            _menuStore.Add(item);
        else
            _menuStore.Update(item);

        TempData["Success"] = $"Saved {item.Name}.";
        return RedirectToAction(nameof(Menu));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteMenuItem(int id)
    {
        _menuStore.Delete(id);
        return RedirectToAction(nameof(Menu));
    }
}
