using DSRRestaurant.Models;
using DSRRestaurant.Services;
using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

public class ReservationController : Controller
{
    private readonly ReservationStore _reservationStore;

    public ReservationController(ReservationStore reservationStore)
    {
        _reservationStore = reservationStore;
    }

    [HttpGet]
    public IActionResult Index()
    {
        return View(new Reservation());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Index(Reservation reservation)
    {
        var requestedDateTime = reservation.Date.Date + reservation.Time;
        if (requestedDateTime < DateTime.Now)
            ModelState.AddModelError(nameof(reservation.Date), "Please choose a future date and time.");

        if (!ModelState.IsValid)
            return View(reservation);

        var saved = _reservationStore.Add(reservation);
        return RedirectToAction(nameof(Confirmation), new { id = saved.Id });
    }

    public IActionResult Confirmation(int id)
    {
        var reservation = _reservationStore.GetById(id);
        if (reservation is null) return RedirectToAction(nameof(Index));
        return View(reservation);
    }
}
