using System.Diagnostics;
using DSRRestaurant.Models;
using DSRRestaurant.Services;
using Microsoft.AspNetCore.Mvc;

namespace DSRRestaurant.Controllers;

public class HomeController : Controller
{
    private readonly MenuStore _menuStore;

    public HomeController(MenuStore menuStore)
    {
        _menuStore = menuStore;
    }

    public IActionResult Index()
    {
        // Feature a handful of signature dishes on the homepage.
        var featured = _menuStore.GetAvailable()
            .Where(i => i.Category is MenuCategory.Mains or MenuCategory.Grill)
            .Take(3)
            .ToList();

        return View(featured);
    }

    public IActionResult About() => View();

    public IActionResult Contact() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

public class ErrorViewModel
{
    public string? RequestId { get; set; }
    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}
