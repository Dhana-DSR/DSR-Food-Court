# DSR Kitchen & Grill — ASP.NET Core MVC Restaurant Site

A full restaurant website built with **ASP.NET Core MVC (.NET 8)**: public menu, cart & checkout,
table reservations, and a staff admin panel — all backed by **in-memory data** (no database required).

## Features

- **Home / About / Contact** — marketing pages with a custom "order ticket" visual identity
- **Menu** — filterable by category (Starters, Mains, Grill, Desserts, Drinks)
- **Cart & Checkout** — session-based cart, pickup or delivery, order placed to an in-memory order list
- **Reservations** — booking form with date/time/party size validation
- **Admin panel** (`/Account/Login`) — dashboard, order status management, reservation status
  management, and full menu CRUD (add / edit / delete dishes)

## Important: no database

All data (menu items, orders, reservations) lives in **in-memory singleton services**
(`Services/MenuStore.cs`, `OrderStore.cs`, `ReservationStore.cs`). That means:

- Changes made in the admin panel work immediately while the app is running
- **Everything resets when the app restarts** — there's nothing to configure, but nothing persists either
- When you're ready for real persistence, swap these singletons for **EF Core** + a `DbContext`
  (SQL Server or SQLite) — the store classes are already shaped like repositories, so the controllers
  won't need to change much.

## Running it

Requires the [.NET 8 SDK](https://dotnet.microsoft.com/download).

```bash
cd DSRRestaurant
dotnet restore
dotnet run
```

Then open the URL shown in the console (typically `https://localhost:5001` or similar).

## Admin access

Go to **Staff sign in** in the footer, or visit `/Account/Login`.

```
Username: admin
Password: DSR@dmin123
```

These are hardcoded in `Controllers/AccountController.cs` for demo purposes — change them before
deploying anywhere public, or replace with ASP.NET Core Identity if you add a database.

## Project structure

```
Controllers/    Home, Menu, Cart, Reservation, Account, Admin
Models/         MenuItem, CartItem, Order, Reservation
Services/       MenuStore, OrderStore, ReservationStore (in-memory), CartSessionExtensions
Filters/        RequireAdminAttribute (guards /Admin/* behind session login)
Views/          Razor views, organized by controller
wwwroot/        site.css (custom design system), site.js (progressive enhancement)
```

## Design notes

The visual identity is built around a kitchen **order ticket** motif (dashed rules, monospace
ticket codes, perforated edges) that carries from the homepage hero through the cart and order
confirmation — since the site's core job is literally producing tickets for the kitchen. Palette:
charcoal, cream, saffron, and brick red. Type: Fraunces (display), Inter (body), JetBrains Mono
(ticket/price detailing), loaded from Google Fonts.

## Extending

- **Add a database**: install `Microsoft.EntityFrameworkCore.SqlServer` (or `.Sqlite`), create a
  `DbContext`, and replace the `MenuStore`/`OrderStore`/`ReservationStore` singletons with
  EF-backed repositories.
- **Add payments**: hook a payment provider's SDK into `CartController.PlaceOrder` before saving
  the order.
- **Add real admin auth**: replace the hardcoded check in `AccountController` with ASP.NET Core
  Identity once you have a user table.
