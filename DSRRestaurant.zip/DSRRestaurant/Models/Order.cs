namespace DSRRestaurant.Models;

public enum OrderStatus
{
    Placed,
    InKitchen,
    Ready,
    Completed,
    Cancelled
}

public enum FulfillmentType
{
    Pickup,
    Delivery
}

public class Order
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Address { get; set; }
    public FulfillmentType FulfillmentType { get; set; }
    public List<CartItem> Items { get; set; } = new();
    public decimal Total => Items.Sum(i => i.LineTotal);
    public OrderStatus Status { get; set; } = OrderStatus.Placed;
    public DateTime PlacedAtUtc { get; set; } = DateTime.UtcNow;
    public string? Notes { get; set; }
}
