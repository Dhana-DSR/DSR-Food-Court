namespace DSRRestaurant.Models;

public enum MenuCategory
{
    Starters,
    Mains,
    Grill,
    Desserts,
    Drinks
}

public class MenuItem
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public MenuCategory Category { get; set; }
    public bool IsVegetarian { get; set; }
    public bool IsSpicy { get; set; }
    public bool IsAvailable { get; set; } = true;

    /// <summary>Short kitchen code printed on order tickets, e.g. "GR-04".</summary>
    public string TicketCode => $"{Category.ToString()[..2].ToUpper()}-{Id:D2}";
}
