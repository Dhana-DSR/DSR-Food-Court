namespace DSRRestaurant.Models;

public class CartItem
{
    public int MenuItemId { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string TicketCode { get; set; } = string.Empty;

    public decimal LineTotal => Price * Quantity;
}
