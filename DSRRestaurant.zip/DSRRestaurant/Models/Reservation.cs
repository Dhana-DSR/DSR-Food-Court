using System.ComponentModel.DataAnnotations;

namespace DSRRestaurant.Models;

public enum ReservationStatus
{
    Pending,
    Confirmed,
    Cancelled
}

public class Reservation
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Tell us your name.")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "We need a phone number to confirm.")]
    [Phone]
    public string Phone { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Date)]
    public DateTime Date { get; set; } = DateTime.Today.AddDays(1);

    [Required]
    [DataType(DataType.Time)]
    public TimeSpan Time { get; set; } = new TimeSpan(19, 0, 0);

    [Range(1, 20, ErrorMessage = "Parties of 1–20. For larger groups, call us.")]
    public int PartySize { get; set; } = 2;

    public string? SpecialRequests { get; set; }

    public ReservationStatus Status { get; set; } = ReservationStatus.Pending;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
